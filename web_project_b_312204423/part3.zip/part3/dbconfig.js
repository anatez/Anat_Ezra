module.exports= {
    HOST:'localhost',
    USER:'root',  
    PASSWORD:"anat1994",
    DB:'anatdb'
}