const path = require('path');
const express = require("express");
const app = express();
const port=8080;
const bodyParser = require("body-parser");
const sql = require("./db.js");
const connection = require('./db');
const CRUD_operations = require("./CRUD.js");
const fs = require('fs');
const CreateDB = require('./CreateDB');
const JSFunc = require('./funcs');
const stringify = require('csv-stringify').stringify;
const { parse } = require("csv-parse");
const CSVToJSON = require('csvtojson');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true
}));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
app.use(express.static('STATIC'));

//UsersDataBase
app.get('/CreateUsersTable',CreateDB.CreateUsersTable);
app.get('/ShowTable', CreateDB.ShowTable);
app.get('/DropTable', CreateDB.DropTable);

//BabySittersDataBase
app.get('/CreateBabySittersTable', CreateDB.CreateBabySittersTable);
app.get('/ShowBabySittersTable', CreateDB.ShowBabySittersTable);
app.get('/DropBabySittersTable', CreateDB.DropBabySittersTable);
app.get("/InsertData", CreateDB.InsertData);

//Route
app.get('/', (req,res)=>{
    res.render('loginPage');
    });

app.get('/getAll', (req, res) => {
    res.render('getAll');
    });
   
app.get('/loginPage', (req, res) => {
     res.render('loginPage');
    });

app.get('/signUp', (req, res) => {
    res.render('signUp');
  });

app.get('/serchePage', (req, res) => {
    res.render('serchePage');
  });

app.get('/Wating', (req, res) => {
    res.render('Wating');
  });

app.get('/Options', (req, res) => {
    res.render('Options');
  });

app.get('/DidntFind', (req, res) => {
    res.render('DidntFind');
  });

app.get('/Favorites', (req, res) => {
    res.render('Favorites');
  });


//create new user
app.post("/createNewUser", CRUD_operations.createNewUser);

//login 
app.post("/auth", function(request, response) {
	// Capture the input fields
	let name = request.body.name;
	let password = request.body.password;
    let email= request.body.email;
	// Ensure the input fields exists and are not empty
	if (name && password) {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('SELECT * FROM users WHERE name = ? AND password = ? AND email= ?', [name, password, email], function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.length > 0) {
				// Authenticate the user
				//request.session.loggedin = true;
				request.body.name = name;
				// Redirect to home page
				response.redirect('/serchePage');
			} else {
				response.send('Incorrect Username and/or Password!');
			}			
			response.end();
		});
	} else {
		response.send('Please enter Username and Password!');
		response.end();
    }
    });


//find BabySitter
app.post("/FindBabySitter", function(request, response) {
	// Capture the input fields
	//let name = request.body.name;
    let city = request.body.city;
    let experience = request.body.experience;
    let price = request.body.price;
    let distance = request.body.distance;
    let lat = request.body.lat;
    let long = request.body.long;
	// Ensure the input fields exists and are not empty
	if (city && experience && price ) {
		// Execute SQL query that'll select the account from the database based on the specified username and password
		connection.query('SELECT * FROM babySitters WHERE city = ? AND experience >= ? AND price <= ?', [city, experience, price], function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.length > 0) {
				// Authenticate the user
				//request.session.loggedin = true;
				// Redirect to BaybySitterOption
                response.render('Options', {
                    pple: results
                });
                //response.send(results);
			} else {
				response.redirect('/DidntFind');
			}			
			response.end();
		});
	} else if (lat && long && distance && !city && experience && price ) {
        connection.query('SELECT * FROM babySitters WHERE experience >= ? AND price <= ?', [experience, price], function(error, results, fields) {
			// If there is an issue with the query, output the error
			if (error) throw error;
			// If the account exists
			if (results.length > 0) {
				// Authenticate the user
				//request.session.loggedin = true;
                console.log("distance:", distance);
                results.forEach((bs, index) => {
                    bs.distance = JSFunc.getDistanceFromLatLonInKm(lat, long, bs.lat, bs.blong);
                });
                results = results.filter(element => 
                    element.distance < distance 
                )
                if (results.length == 0) {
                    response.redirect('/DidntFind');
                }
                else {
                    // Redirect to BaybySitterOption
                    response.render('Options', {
                        pple: results
                    });
                }
                //response.send(results);
			} else {
				response.redirect('/DidntFind');
			}			
			response.end();
		});
    } else {
		response.send('Please enter Username and Password!');
		response.end();
    }
    });



app.listen(port,()=>{
    console.log("Server is running on port"+port)
});
